@include('template.header')
        @yield('content')
@include('template.footer')