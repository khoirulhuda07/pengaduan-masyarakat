
<?php $__env->startSection('title', 'Riwayat Pengaduan'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
<div class="col-12">
  <div class="card">
    <div class="card-body">
          <h2 class="az-content-title text-center">Riwayat Pengaduan Anda</h2>
            <div class="table-responsive">
            <table class="table table-bordered  table-hover mg-b-0">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Nama Pengadu</th>
                  <th>Detail Lokasi</th>
                  <th>Jenis Pengaduan</th>
                  <th>Deskripsi</th>
                  <th>dokument pendukung</th>
                  <th>Status</th>
                  <th>Lihat Balasan</th>
                  <th>aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $pengaduan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($loop->iteration); ?></th>
                  <td><?php echo e($data->NAMA); ?></td>
                  <td><?php echo e($data->LOKASI); ?></td>
                  <td><?php echo e($data->JENIS); ?></td>
                  <td><?php echo e($data->PENGADUAN); ?></td>
                  <?php if($data->DOKUMEN == null): ?>
                  <td>Tidak ada</td>
                  <?php else: ?>
                  <td><button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#pendukung<?php echo e($data->ID_PENGADUAN); ?>"><i class="fas fa-envelope-open-text"></i></button></td>
                  <?php endif; ?>
                  <td><?php echo e($data->STATUS); ?></td>
                  <?php if($data->STATUS == 'diproses'): ?>
                  <td>Tidak ada</td>
                  <?php else: ?>
                  <td><button class="btn btn-outline-primary" data-toggle="modal" data-target="#pesan<?php echo e($data->ID_PENGADUAN); ?>" type="button"><i class="fas fa-envelope-open-text"></i></button></td>
                  <?php endif; ?>
                  <td>
                  <?php if(auth()->check() && auth()->user()->level == 'petugas' && $data->STATUS != 'ditolak' && $data->STATUS != 'disetuji'): ?>
                  <button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#exampleModal<?php echo e($data->ID_PENGADUAN); ?>">
                    Tanggapi
                  </button>
                  <?php else: ?>

                <?php endif; ?>
                  <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#hapusModal<?php echo e($data->ID_PENGADUAN); ?>">
                  <i class="fa fa-trash" aria-hidden="true"></i>
                  </button>
                  
                  <div class="modal fade" id="pendukung<?php echo e($data->ID_PENGADUAN); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body  text-center">
                      <?php
                          $path = asset('storage/' . $data->DOKUMEN);
                          $extension = pathinfo($data->DOKUMEN, PATHINFO_EXTENSION);
                      ?>
                      <?php if(in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])): ?>
                        <img src="<?php echo e(url('storage/'.$data->DOKUMEN)); ?>" alt="Dokumen Gambar" class="img-fluid">
                      <?php elseif($extension === 'pdf'): ?>
                        <embed src="<?php echo e(url('storage/'.$data->DOKUMEN)); ?>" type="application/pdf" width="100%" height="500px" />
                      <?php endif; ?>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                      </div>
                    </div>
                  </div>
                </div>


                <div class="modal fade" id="pesan<?php echo e($data->ID_PENGADUAN); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="staticBackdropLabel">Surat Balasan</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body" style="word-wrap: break-word; white-space: pre-wrap;">
                     <p><?php echo e($data->balasan->KETERANGAN ?? 'Belum Ada Balasan'); ?></p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <!-- <button type="button" class="btn btn-primary">Understood</button> -->
                    </div>
                  </div>
                </div>
              </div>


              <div class="modal fade" id="exampleModal<?php echo e($data->ID_PENGADUAN); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog">
                    <div class="modal-content">
                    <form action="<?php echo e(url('/pengaduan/tanggapi/'.$data->ID_PENGADUAN)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="modal-header">
                        <h5 class="modal-title" id="staticBackdropLabel">balan Pesan</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                      <select class="form-control" name="status">
  <option selected value="">ubah status pesan</option>
  <option value="ditolak">Ditolak</option>
  <option value="disetujui">Disetujui</option>
</select>
<input class="form-control mt-2 mb-2" type="text" name="keterangan" placeholder="Kirim Balasan DIsini">
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Kirim</button>
                      </div>
                    </form>
                    </div>
                  </div>
                </div>

                <div class="modal fade" id="hapusModal<?php echo e($data->ID_PENGADUAN); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                  <form action="<?php echo e(url('pengaduan/hapus/'.$data->ID_PENGADUAN)); ?>" method="POST" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Hapus Pengaduan</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body" style="word-wrap: break-word; white-space: pre-wrap;">
                 <p>apakah anda ingin menghapus pengaduan ini ?</p>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Hapus</button>
                    </div>
                  </form>
                  </div>
                </div>
              </div>
                </td>
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
      
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.appuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\huda\Desktop\pengaduan masyarakat\PengaduanMasyarakat\resources\views/data.blade.php ENDPATH**/ ?>