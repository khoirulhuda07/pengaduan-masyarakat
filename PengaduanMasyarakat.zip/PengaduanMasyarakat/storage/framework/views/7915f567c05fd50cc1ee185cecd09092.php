<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-90680653-2"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'UA-90680653-2');
    </script>

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Twitter -->
    <!-- <meta name="twitter:site" content="@bootstrapdash">
    <meta name="twitter:creator" content="@bootstrapdash">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Azia">
    <meta name="twitter:description" content="Responsive Bootstrap 4 Dashboard Template">
    <meta name="twitter:image" content="https://www.bootstrapdash.com/azia/img/azia-social.png"> -->

    <!-- Facebook -->
    <!-- <meta property="og:url" content="https://www.bootstrapdash.com/azia">
    <meta property="og:title" content="Azia">
    <meta property="og:description" content="Responsive Bootstrap 4 Dashboard Template">

    <meta property="og:image" content="https://www.bootstrapdash.com/azia/img/azia-social.png">
    <meta property="og:image:secure_url" content="https://www.bootstrapdash.com/azia/img/azia-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600"> -->

    <!-- Meta -->
    <meta name="description" content="Responsive Bootstrap 4 Dashboard Template">
    <meta name="author" content="BootstrapDash">

    <title>Halaman <?php echo $__env->yieldContent('title'); ?></title>

    <!-- vendor css -->
    <link href="<?php echo e(asset('user2/lib/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user2/css/ionicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user2/lib/typicons.font/typicons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('user2/lib/flag-icon-css/css/flag-icon.min.css')); ?>" rel="stylesheet">

    <!-- azia CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('user2/css/azia.css')); ?>">

  </head>
  <body>
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="az-header">
      <div class="container">
        <div class="az-header-left">
        <img src="<?php echo e(asset('user2/img/logo.png')); ?>" class="az-logo" style="" width="50px" alt="">
          <a href="" id="azMenuShow" class="az-header-menu-icon d-lg-none"><span></span></a>
        </div><!-- az-header-left -->
        <div class="az-header-menu">
          <div class="az-header-menu-header">
          <img src="<?php echo e(asset('user2/img/logo.png')); ?>" class="az-logo" style="" width="50px" alt="">
            <a href="" class="close">&times;</a>
          </div><!-- az-header-menu-header -->
          <ul class="nav">
          <?php if(auth::check() && auth::user()->level == 'user'): ?>
            <li class="nav-item <?php echo e(Request::is('/') ? 'active' : ''); ?>">
              <a href="<?php echo e(url('/')); ?>" class="nav-link"><i class="typcn typcn-chart-area-outline"></i> Dashboard</a>
            </li>
            <li class="nav-item <?php echo e(Request::is('pengaduan') ? 'active' : ''); ?>">
              <a href="<?php echo e(url('/pengaduan')); ?>" class="nav-link"><i class="typcn typcn-document"></i>Pengaduan</a>
            </li>
            <?php else: ?>
            <?php endif; ?>
            <?php if(auth::check() && (auth::user()->level == 'user'||auth::user()->level == 'petugas')): ?>
            <li class="nav-item <?php echo e(Request::is('riwayat') ? 'active' : ''); ?>">
              <a href="<?php echo e(url('/riwayat')); ?>" class="nav-link"><i class="typcn typcn-document"></i>Riwayat Pengaduan</a>
            </li>
            <?php else: ?>
            <?php endif; ?>
            <?php if(auth::check() && auth::user()->level == 'admin'): ?>
            <li class="nav-item <?php echo e(Request::is('akun') ? 'active' : ''); ?>">
              <a href="<?php echo e(url('/akun')); ?>" class="nav-link"><i class="typcn typcn-document"></i>Kelola Akun</a>
            </li>
            <?php else: ?>
            <?php endif; ?>
          </ul>
        </div><!-- az-header-menu -->
        <div class="az-header-right">
          <div class="dropdown az-profile-menu">
            <?php if(empty(Auth::user()->foto)): ?>
            <a href="" class="az-img-user"><img src="<?php echo e(asset('user2/img/no_foto.jpg')); ?>" alt=""></a>
            <?php else: ?>
            <a href="" class="az-img-user"><img src="<?php echo e(asset('storage/photo_user/'.Auth::user()->foto)); ?>" alt=""></a>
            <?php endif; ?>
            <div class="dropdown-menu">
            <div class="az-dropdown-header d-sm-none">
                <a href="" class="az-header-arrow"><i class="fa fa-arrow-left" aria-hidden="true"></i></a>
              </div>
              <div class="az-header-profile">
                <div class="az-img-user">
                <?php if(empty(Auth::user()->foto)): ?>
                <img src="<?php echo e(asset('user2/img/no_foto.jpg')); ?>" alt="">
                <?php else: ?>
                  <img src="<?php echo e(asset('storage/photo_user/'.Auth::user()->foto)); ?>" alt="">
                  <?php endif; ?>
                </div><!-- az-img-user -->
                <h6><?php echo e(Auth::user()->name); ?></h6>
                <!-- <span>Premium Member</span> -->
              </div><!-- az-header-profile -->

              <a href="<?php echo e(url('/profile')); ?>"  class="dropdown-item"><i class="typcn typcn-user-outline"></i> My Profile</a>
           
              <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                  document.getElementById('logout-form').submit();" class="dropdown-item"><i class="typcn typcn-power-outline"></i> Log Out</a>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
              <?php echo csrf_field(); ?>
            </form>
            </div><!-- dropdown-menu -->
          </div>
        </div><!-- az-header-right -->
      </div><!-- container -->
    </div><!-- az-header --><?php /**PATH C:\Users\huda\Desktop\pengaduan masyarakat\PengaduanMasyarakat\resources\views/template/header.blade.php ENDPATH**/ ?>